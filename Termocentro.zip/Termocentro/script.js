$(document).ready(function () {
    const segmentMap = {
        0: "abcdef",
        1: "bc",
        2: "abdeg",
        3: "abcdg",
        4: "bcfg",
        5: "acdfg",
        6: "acdefg",
        7: "abc",
        8: "abcdefg",
        9: "abcdfg"
    };

    var tempAtual = 0;
    var seconds = 0;

    function updateDigit(digitId, number) {
        const segments = segmentMap[number];
        if (typeof segments === 'string') {
            $(`#${digitId} .segment`).removeClass("on");
            for (let segment of segments) {
                $(`#${digitId} .segment.${segment}`).addClass("on");
            }
        }
    }

    function displayTemperature(temp) {
        const tempParts = temp.toFixed(2).split('.');
        const integerPart = tempParts[0].padStart(3, '0');

        updateDigit("digit0", integerPart[0]);
        updateDigit("digit1", integerPart[1]);
        updateDigit("digit2", integerPart[2]);
        updateDigit("digit3", tempParts[1][0]);
        updateDigit("digit4", tempParts[1][1]);
    }

    $('#telefoneRegistro').mask('(00) 00000-0000');
    $('.logged').hide();

    $('#registerButton').on('click', async function () {
        let isValid = true;

        $('#registerModal input[required]').each(function () {
            if (!$(this).val()) {
                isValid = false;
                $(this).addClass('is-invalid');
            } else {
                $(this).removeClass('is-invalid');
            }
        });

        const emailField = $('#emailRegistro');
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailRegex.test(emailField.val())) {
            isValid = false;
            emailField.addClass('is-invalid');
            emailField.next('.invalid-feedback').text('Por favor, insira um e-mail válido.');
        } else {
            emailField.removeClass('is-invalid');
        }

        if (isValid) {
            const email = $('#emailRegistro').val();
            const nome = $('#nomeRegistro').val();
            const telefone = $('#telefoneRegistro').val();
            const senha = $('#senhaRegistro').val();

            await $.ajax({
                url: 'http://localhost:3000/novo-usuario',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ email, nome, telefone, senha }),
                success: function (data) {
                    alert(data.message);

                    $('#registerModal').modal('hide');
                    $('#registerModal input').val('');
                },
                error: function (err) {
                    alert('Erro ao enviar os dados');
                    console.error(err);
                },
            });
        }
    });

    $('#registerModal input').on('input', function () {
        $(this).removeClass('is-invalid');
    });

    $('#loginButton').on('click', async function () {
        let isValid = true;

        $('#loginModal input[required]').each(function () {
            if (!$(this).val()) {
                isValid = false;
                $(this).addClass('is-invalid');
            } else {
                $(this).removeClass('is-invalid');
            }
        });

        if (isValid) {
            const email = $('#emailLogin').val();
            const senha = $('#senhaLogin').val();

            await $.ajax({
                url: 'http://localhost:3000/login',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ email, senha }),
                success: function (data) {
                    alert(data.message);

                    localStorage.setItem('userLogged', JSON.stringify(data.user));

                    $('#loginModal').modal('hide');
                    $('#loginModal input').val('');

                    $('.not-logged').hide();
                    $('.logged').show();

                    $('.logged .user-name').text(data.user.NOME);
                },
                error: function (err) {
                    alert(err.responseJSON.message);
                },
            });
        }
    });

    $('#loginModal input').on('input', function () {
        $(this).removeClass('is-invalid');
    });

    $('.btn-logout').on('click', function () {
        localStorage.removeItem('userLogged');
        $('.logged').hide();
        $('.not-logged').show();
        alert('Você saiu da sua conta.');
    });

    $('.btn-save').on('click', function () {
        var valor = $('#temp-desejada').val().toString();
        client.publish('termocentro_target', valor);
    });

    const userLogged = JSON.parse(localStorage.getItem('userLogged'));

    if (userLogged) {
        $('.not-logged').hide();
        $('.logged').show();
        $('.logged .user-name').text(userLogged.NOME);
    }

    const ctx = $('#tempChart')[0].getContext('2d');
    const tempData = {
        labels: [],
        datasets: [{
            label: 'Temperatura (°C)',
            borderColor: 'rgba(75, 192, 192, 1)',
            data: [],
            fill: false,
            tension: 0.1
        }]
    };

    const config = {
        type: 'line',
        data: tempData,
        options: {
            scales: {
                x: {
                    type: 'linear',
                    position: 'bottom',
                    title: {
                        display: true,
                        text: 'Tempo (segundos)'
                    },
                    ticks: {
                        stepSize: 1 // Define que o eixo X será incrementado em 1 a cada segundo
                    }
                },
                y: {
                    beginAtZero: false,
                    title: {
                        display: true,
                        text: 'Temperatura (°C)'
                    }
                }
            }
        }
    };

    const tempChart = new Chart(ctx, config);

    const client = mqtt.connect('ws://localhost:9001/');

    client.on('connect', function () {
        console.log('Conectado ao broker MQTT');
        client.subscribe('termocentro_leitura', function (err) {
            if (!err) {
                console.log('Inscrito no tópico Leitura');
            }
        });
        client.subscribe('termocentro_target', function (err) {
            if (!err) {
                console.log('Inscrito no tópico Target');
            }
        });
    });

    client.on('message', function (topic, message) {
        if (topic == 'termocentro_leitura') {
            let parsedData = JSON.parse(message.toString());
            tempAtual = parseFloat(parsedData.temperatura);

            $('#temp-real').text('Temperatura: ' + tempAtual + ' ºC');
            tempData.labels.push(seconds);
            tempData.datasets[0].data.push(tempAtual);

            if (tempData.labels.length > 60) {
                tempData.labels.shift();
                tempData.datasets[0].data.shift();
            }

            tempChart.update('none');

            seconds++;
        }
    });

    setInterval(() => {
        displayTemperature(tempAtual);
    }, 1000);
});