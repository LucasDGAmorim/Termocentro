const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(cors());

// Configuração do MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'b5u7w0D@',
    database: 'termocentro',
});

db.connect((err) => {
    if (err) {
        console.error('Erro ao conectar ao MySQL:', err);
        return;
    }
    console.log('Conectado ao MySQL');
});

// Middleware
app.use(bodyParser.json());

// Rota para inserir usuário
app.post('/novo-usuario', (req, res) => {
    const { email, nome, telefone, senha } = req.body;

    const query = 'INSERT INTO usuario (nome, email, senha, telefone) VALUES (?, ?, ?, ?)';
    db.query(query, [nome, email, senha, telefone], (err, result) => {
        if (err) {
            console.error('Erro ao inserir dados:', err);
            res.status(500).json({ message: 'Erro ao salvar o usuário' });
            return;
        }
        res.json({ message: 'Você está registrado no Termocentro!' });
    });
});

app.post('/login', (req, res) => {
    const { email, senha } = req.body;

    const query = 'SELECT * FROM usuario WHERE email = ?';
    db.query(query, [email], (err, results) => {
        if (err) {
            console.error('Erro ao consultar o banco de dados:', err);
            res.status(500).json({ message: 'Erro no servidor' });
            return;
        }

        if (results.length === 0) {
            res.status(404).json({ message: 'Usuário não encontrado' });
            return;
        }

        const usuario = results[0];

        if (usuario.SENHA != senha) {
            res.status(401).json({ message: 'Senha incorreta' });
            return;
        }

        res.json({
            message: `Bem-vindo(a), ${usuario.NOME}!`,
            user: usuario
        });
    });
});

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});